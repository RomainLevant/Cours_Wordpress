<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./footer.php
// Template: Partial
// More info at https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/#footer-php

// required: no

//======================================================================
?>
    </div>


    <!-- Pied de page -->
    <footer class="main-footer">
        footer
    </footer>

</body>
</html>