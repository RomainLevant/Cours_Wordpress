<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./archive.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#archive-php
// Use this file to display the posts archive

// required: no

//======================================================================
?>

Archive