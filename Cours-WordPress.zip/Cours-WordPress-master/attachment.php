<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./attachment.php
// Template: Attachment Template
// More info at https://developer.wordpress.org/themes/template-files-section/attachment-template-files/#attachment-php

// required: no

//======================================================================
?>

attachment