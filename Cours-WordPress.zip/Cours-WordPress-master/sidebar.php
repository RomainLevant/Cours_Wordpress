<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./sidebar.php
// Template: Partial
// More info at https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/#sidebar-php

// required: no

//======================================================================
?>

Ici on ajouter les elemnts HTML de ma sidebar