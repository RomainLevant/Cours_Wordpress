<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./tag.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#category-php-tag-php-and-taxonomy-php

// required: no

//======================================================================
?>

tag