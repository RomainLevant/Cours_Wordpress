<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./search.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#search-php

// required: no

//======================================================================
?>

search