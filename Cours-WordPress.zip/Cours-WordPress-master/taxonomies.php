<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./taxonomies.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#category-php-tag-php-and-taxonomy-php

// required: no

//======================================================================
?>

taxonomies