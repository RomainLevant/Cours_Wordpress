<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./author.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#author-php
// Use this file to display the posts archive by author

// required: no

//======================================================================
?>

Archive by author