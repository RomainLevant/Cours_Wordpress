<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./date.php
// Template: Post Template
// More info at https://developer.wordpress.org/themes/template-files-section/post-template-files/#date-php
// Use this file to display the posts archive by date

// required: no

//======================================================================
?>

Archive by date