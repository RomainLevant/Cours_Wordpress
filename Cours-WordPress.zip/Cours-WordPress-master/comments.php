<?php
//======================================================================
// NetLab WordPress Theme Boilerplate
//======================================================================

// File: ./404.php
// Template: Partial
// More info at https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/#comments-php

// required: no

//======================================================================
?>

comments